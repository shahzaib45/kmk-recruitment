---
title: "Web Developer"
date: 2021-07-01T02:08:41+05:00
draft: false
industry: Financial Services
jobtype: Temporary
location: "Lorem Ipsum"
salary: "Lorem Ipsum"
qualifications: "Lorem Ipsum"
skills: "Lorem Ipsum"
summary: "Lorem Ipsum"
responsibilities: "Lorem Ipsum"
requirements: "Lorem Ipsum"
imgfile: /assets/img/vacancy/startup-hr.png
---